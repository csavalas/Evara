from secrets import token_bytes
import os

print("*****************************************")
print("**Welcome to the One Time Pad Generator**")
print("*****************************************")

while True:
    pad_name = input("Name your pad: ")
    if pad_name:
        idx = pad_name.find('.')
        if idx == -1  or idx == len(pad_name) - 1:
            pad_name = pad_name + ".otp"
        break

while True:
    pad_size = input("Pad Size (MB): ")
    try:
        pad_size = int(pad_size)
    except ValueError:
        # Handle the exception
        print('Please enter an integer')
        continue
    if pad_size < 0:
        print('Please enter a positive value')
    elif pad_size > 25:
        print('Please enter a value of 25 or less')
    else:
        break

f = open(pad_name, 'wb')
for i in range(pad_size * 1024):
    f.write(token_bytes(1024))
f.close()

print("Successfully saved '"+pad_name+"' to '"+os.getcwd()+"'.")