from cs50 import SQL
import re
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_socketio import SocketIO, emit
from application_extras import login_required

#########################################
#########################################

# Flask/SocketIO initialization
app = Flask(__name__)
app.config['SECRET_KEY'] = ']ou;EY)V24qz[r|Z"KP)hO8RB=g!4P'
socketio = SocketIO(app)
socketio.init_app(app, cors_allowed_origins="*")


# Disable Caching
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Flask Config
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Globals
client_map = {}
show_once = {}
server_error_session = 'Session expired, redirecting...'
server_error_session_2 = 'Duplicate sessions, redirecting...'
server_error_size = 'Message too large. '
server_error_index = 'Invalid index proposed by client.'
warning_style = "color: red;"
server_warning_prefix = "<p style='color: #ffa500; margin: 0px; padding: 5px;'><strong>"
server_warning_suffix = "</strong></p>"
server_message_prefix = "<p style='color: white; margin: 0px; padding: 5px;'>"
server_message_suffix = "</p>"
max_thumb_size = 1048576 * 3
max_upload_size = 1048576 * 4
pass_special = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})'
pass_allowed = r'^[A-Za-z0-9!@#\$%\^&\*]*$'
user_allowed = r'^[A-Za-z0-9_]*$'

#########################################
#########################################


@app.route('/')
@login_required
# Messenger (default) tab of the interface which additionally displays all conversations in a sidebar
def index():
    print("/ user_id:", session["user_id"])
    return render_template('messenger.html', messenger_active=True, max_upload_size=max_upload_size)

#########################################


@app.route("/friends", methods=["GET", "POST"])
@login_required
# Friends tab of the interface; includes friend requests, user search, and conversation creation
def friends():
    print("/friends client:", request.form)
    return render_template('friends.html', friends_active=True)

#########################################


@app.route("/manage", methods=["GET", "POST"])
@login_required
# Select account management options exposed to the end-user
def manage():
    print("/manage client:", request.form)
    db = SQL("sqlite:///db.db")
    w = {}
    p = {}
    if request.method == "POST":
        if request.form.get('change-username'):
            # Validate Input before processing request
            if not request.form.get("inputUN"):
                w["username_warning"] = warning_style
            else:
                if len(db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("inputUN").lower())) != 0:
                    w["server_warning_u"] = server_warning_prefix + "Username already taken" + server_warning_suffix
                    p["persist_username"] = request.form.get("inputUN")
                elif len(request.form.get("inputUN")) < 2:
                    w["server_warning_u"] = server_warning_prefix + "Username too short." + server_warning_suffix
                    p["persist_username"] = request.form.get("inputUN")
                elif re.match(user_allowed, request.form.get("inputUN")) is None:
                    w["server_warning_u"] = server_warning_prefix + ("Usernames may only contain:"
                                                                     "letters, numbers, or _'s.") + server_warning_suffix
                    p["persist_username"] = request.form.get("inputUN")
                else:
                    db.execute("UPDATE users SET username = :username WHERE id = :id",
                               username=request.form.get("inputUN").lower(), id=session["user_id"])
                    p['server_message_u'] = server_message_prefix + "Username successfully changed!" + server_message_suffix
        elif request.form.get('change-password'):
            # Validate Input before processing request
            if not request.form.get("inputPass2a") or not request.form.get("inputPass2b"):
                w["password_warning"] = warning_style
            elif request.form.get("inputPass2a") != request.form.get("inputPass2b"):
                w["server_warning_p"] = server_warning_prefix + "Passwords don't match" + server_warning_suffix
            elif re.match(pass_special, request.form.get("inputPass2a")) is None or re.match(pass_allowed, request.form.get("inputPass2a")) is None:
                w["server_warning_p"] = server_warning_prefix + ("Your password must be 8 characters long & contain at least one:"
                                                                 "<br>special (allowed: !@#$%^&*), upper, lower, & numeric character.") + server_warning_suffix
            else:
                db.execute("UPDATE users SET password = :password WHERE id = :id",
                           password=generate_password_hash(request.form.get("inputPass2a")), id=session["user_id"])
                p['server_message_p'] = server_message_prefix + "Password successfully changed!" + server_message_suffix
        elif request.form.get('delete-account'):
            # Validate Input before processing request
            if not request.form.get("inputDM"):
                w["delete_warning"] = warning_style
            elif request.form.get("inputDM").lower() != "delete me":
                w["server_warning_d"] = server_warning_prefix + "Enter 'delete me' to remove all account data" + server_warning_suffix
            else:
                return render_template('manage.html', w=w, p=p, manage_active=True, username="[DELETED]", delete_account="delete me")

    rows = db.execute("SELECT * FROM users WHERE id = :id",
                      id=session["user_id"])

    print("/manage server:", w, p)
    return render_template('manage.html', w=w, p=p, manage_active=True, username=rows[0]['username'])

#########################################


@app.route("/login", methods=["GET", "POST"])
# Login a user or present opportunity to login
def login():
    print("/login client:", request.form)
    session.clear()
    w = {}
    p = {}
    if request.method == "POST":
        # Validate Input before processing request
        if not request.form.get("inputUN"):
            w["username_warning"] = warning_style
        else:
            p["persist_username"] = request.form.get("inputUN")
        if not request.form.get("inputPass"):
            w["password_warning"] = warning_style

        if not bool(w):
            # Log in user
            db = SQL("sqlite:///db.db")
            rows = db.execute("SELECT * FROM users WHERE username = :username OR email = :username",
                              username=request.form.get("inputUN").lower())
            if len(rows) != 1 or not check_password_hash(rows[0]["password"], request.form.get("inputPass")):
                w["server_warning"] = "Username/password mismatch"
            else:
                session["user_id"] = rows[0]["id"]
                return redirect("/")

        if "server_warning" in w:
            w["server_warning"] = server_warning_prefix + w["server_warning"] + server_warning_suffix

    print("/login server:", w, p)
    return render_template("login.html", w=w, p=p, login_active=True)

#########################################


@app.route("/register", methods=["GET", "POST"])
# Register a new user or present opportunity to register
def register():
    print("/register client:", request.form)
    w = {}
    p = {}
    if request.method == "POST":
        db = SQL("sqlite:///db.db")

        # Validate Input before processing request
        if not request.form.get("inputFull"):
            w["name_warning"] = warning_style
        else:
            p["persist_name"] = request.form.get("inputFull")
        if not request.form.get("inputEmail1"):
            w["email_warning"] = warning_style
        else:
            p["persist_email1"] = request.form.get("inputEmail1")
        if not request.form.get("inputEmail2"):
            w["email_warning"] = warning_style
        else:
            p["persist_email2"] = request.form.get("inputEmail2")
        if request.form.get("inputEmail1").lower() == request.form.get("inputEmail2").lower():
            if len(db.execute("SELECT * FROM users WHERE email = :email", email=request.form.get("inputEmail1").lower())) != 0:
                w["server_warning"] = "Email already registered"
        else:
            w["server_warning"] = "Emails don't match"
        p['persist_pass1'] = request.form.get("inputPass1")
        p['persist_pass2'] = request.form.get("inputPass2")
        if not request.form.get("inputPass1") or not request.form.get("inputPass2"):
            w["password_warning"] = warning_style
        elif request.form.get("inputPass1") != request.form.get("inputPass2"):
            w["server_warning"] = "Passwords don't match"
        elif re.match(pass_special, request.form.get("inputPass1")) is None or re.match(pass_allowed, request.form.get("inputPass1")) is None:
            w["server_warning"] = "Your password must be 8 characters long & contain at least one:<br>special (allowed: !@#$%^&*), upper, lower, & numeric character."
        if not request.form.get("inputUN"):
            w["username_warning"] = warning_style
        else:
            if len(db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("inputUN").lower())) != 0:
                w["server_warning"] = "Username already taken"
            elif len(request.form.get("inputUN")) < 2:
                w["server_warning"] = "Username too short"
            elif re.match(user_allowed, request.form.get("inputUN")) is None:
                w["server_warning"] = "Usernames may only contain letters, numbers, or _'s."
            p["persist_username"] = request.form.get("inputUN")

        # Register user
        if not bool(w):
            session["user_id"] = db.execute("INSERT INTO users (username, name, password, email) VALUES(:username, :name, :password, :email)",
                                            username=request.form.get("inputUN").lower(), name=request.form.get("inputFull"), password=generate_password_hash(request.form.get("inputPass1")), email=request.form.get("inputEmail1").lower())
            return redirect("/")

        if "server_warning" in w:
            w["server_warning"] = server_warning_prefix + w["server_warning"] + server_warning_suffix

    print("/register server:", w, p)
    return render_template("register.html", w=w, p=p, register_active=True)

#########################################


@app.route("/logout")
# Logs user out completely
def logout():
    print("/logout:")
    # Clear the session and delete latest socket-io client id from client_map
    if session and "user_id" in session and session["user_id"] in client_map:
        del client_map[session["user_id"]]
    session.clear()
    return redirect("/")

#########################################


def cb(methods=['GET', 'POST']):
    # Empty callback function
    return

#########################################
#########################################


def duplicate_session():
    # Update client map on every request AND force redirect in case of expired/duplicate session
    if not session:
        print('msg server:', server_error_session, request.sid)
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': server_error_session, 'redirect': 1}], callback=cb, room=request.sid)
        return True
    elif session["user_id"] in client_map and client_map[session["user_id"]] != request.sid:
        print('msg server:', server_error_session_2, client_map[session["user_id"]])
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': server_error_session_2, 'redirect': 1}], callback=cb, room=client_map[session["user_id"]])
    client_map[session["user_id"]] = request.sid
    return False

#########################################
#########################################


@socketio.on('delete client')
# Called after a user has confirmed a request to delete their account
def delete_client(json, methods=['GET', 'POST']):
    print('delete client:', request.sid)
    if duplicate_session():
        return
    db = SQL("sqlite:///db.db")

    # Remove user from all conversations, delete messages, and unfriend friends
    rows = db.execute("SELECT * FROM participants WHERE user_id != :uid AND conv_id IN (SELECT conv_id FROM participants WHERE user_id = :uid)",
                      uid=session["user_id"])
    db.execute("UPDATE messages SET ciphertext = 'Deleted message', from_id = NULL, file_name = NULL WHERE from_id = :fid",
               fid=session["user_id"])
    db.execute("DELETE FROM participants WHERE user_id = :uid",
               uid=session["user_id"])

    convs_refresh_uids = {}

    # Send signal to all affected clients to refresh conversation list & current conversation
    for row in rows:
        if row["user_id"] in client_map:
            socketio.emit('conv refresh server', row, callback=cb, room=client_map[row["user_id"]])
            if row["user_id"] not in convs_refresh_uids:
                convs_refresh_uids[row["user_id"]] = 1
                socketio.emit('convs refresh server', {}, callback=cb, room=client_map[row["user_id"]])

    rows = db.execute("SELECT * FROM friendships WHERE requester_id = :uid OR requestee_id = :uid",
                      uid=session["user_id"])
    db.execute("DELETE FROM friendships WHERE requester_id = :uid OR requestee_id = :uid",
               uid=session["user_id"])
    db.execute("DELETE FROM users WHERE id = :id",
               id=session["user_id"])

    # Send signal to all affected clients to refresh friends/requests,
    for row in rows:
        notify_user = row["requester_id"]
        if session["user_id"] == notify_user:
            notify_user = row["requestee_id"]
        if notify_user in client_map:
            socketio.emit('reqcon server', {'deleted_user': session["user_id"]}, callback=cb, room=client_map[notify_user])

    # Emit response back to requesting client
    print('delete server:', request.sid)
    socketio.emit('delete server', {}, callback=cb, room=request.sid)

#########################################
#########################################


@socketio.on('msg client')
# Called when client intitiates sending a message or when message is resent with a new index after server mandate
def msg_client(json, methods=['GET', 'POST']):
    print('msg client:', request.sid)
    if duplicate_session():
        return
    db = SQL("sqlite:///db.db")

    # Don't allow empty message insertion
    if json["your_message"] == "":
        return

    # Security check: make sure user is a member of conversation
    rows_1 = db.execute("SELECT * FROM participants WHERE user_id = :uid AND conv_id = :cid",
                        uid=session["user_id"], cid=json["conv_id"])
    if len(rows_1) < 1:
        return

    # Enforce upload limit
    if len(json["your_message"]) > max_upload_size:
        print('msg server:', server_error_size, request.sid)
        print('msg server:', len(json["your_message"]), request.sid)
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': server_error_size}], callback=cb, room=request.sid)
        return

    # Ensure valid proposed pad index
    rows_1 = db.execute("SELECT * FROM conversations WHERE id = :id",
                        id=json["conv_id"])
    new_index = rows_1[0]["current_index"] + json["message_length"]
    if json["proposed_index"] != rows_1[0]["current_index"]:
        json["correct_index"] = rows_1[0]["current_index"]
        print('msg resend server:', request.sid)
        socketio.emit('msg resend server', json, callback=cb, room=request.sid)
        return

    # Ensure message will fit in pad
    if new_index > rows_1[0]["total_size"]:
        print('msg server:', server_error_size, request.sid)
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': server_error_size + str(rows_1[0]["total_size"] - rows_1[0]["current_index"])+' bytes remaining in pad.'}], callback=cb, room=request.sid)
        return

    # Insert message into conversation
    db.execute("UPDATE conversations SET current_index = :cix, last_sent = ((julianday('now') - 2440587.5) * 86400.0) WHERE id = :id",
               cix=new_index, id=json["conv_id"])
    message_id = db.execute("INSERT INTO messages (conv_id, from_id, pad_index, msg_length, ciphertext, file_name, thumbable) VALUES(:cid, :fid, :pix, :msl, :cpt, :fnm, :tmb)",
                            cid=json["conv_id"], fid=session["user_id"], pix=rows_1[0]["current_index"], msl=json["message_length"], cpt=json["your_message"], fnm=json["file_name"], tmb=json["thumbable"])

    # Add display name and new pad index to rows_1[0] to emit to impacted clients at function's end
    rows_1 = db.execute("SELECT * FROM messages WHERE id = :id",
                        id=message_id)
    rows_2 = db.execute("SELECT * FROM users WHERE id = :fid",
                        fid=rows_1[0]["from_id"])
    rows_1[0]["name"] = rows_2[0]["name"]
    rows_1[0]["new_index"] = new_index

    # If the upload is outside the size range, or is an invalid type of media, prevent auto-download
    if rows_1[0]["file_name"] != None:
        if len(rows_1[0]["ciphertext"]) > max_thumb_size or rows_1[0]["thumbable"] is None:
            rows_1[0]["ciphertext"] = ""

    # Finally, send message data to all impacted clients
    rows_2 = db.execute("SELECT user_id FROM participants WHERE conv_id = :cid",
                        cid=json["conv_id"])
    for row_2 in rows_2:
        if row_2["user_id"] in client_map:
            print('msg server:', client_map[row_2["user_id"]])
            socketio.emit('msg server', rows_1, callback=cb, room=client_map[row_2["user_id"]])

#########################################


@socketio.on('convs client')
# Called to display/refresh list of conversations on the messenger sidebar, as well as friend request/new message notifications
def convs_client(json, methods=['GET', 'POST']):
    print('convs client:', request.sid)
    if duplicate_session():
        return
    db = SQL("sqlite:///db.db")

    # Check if there are pending friend requests, and ultimately display as much on the messenger sidebar
    new_friends = len(db.execute("SELECT * FROM friendships WHERE mutual = 0 AND requestee_id = :uid",
                                 uid=session["user_id"]))

    # Find conversation membership, use this to display on the sidebar
    rows_1 = db.execute("SELECT * FROM conversations WHERE id IN (SELECT conv_id FROM participants WHERE user_id = :uid)",
                        uid=session["user_id"])
    for row_1 in rows_1:
        # FOR EACH of the conversation ID's get all the participants to display as a subheading on the sidebar
        rows_2 = db.execute("SELECT * FROM users WHERE id IN (SELECT user_id FROM participants WHERE conv_id = :cid)",
                            cid=row_1["id"])
        row_1["participants_list"] = ""
        for row_2 in rows_2:
            if row_2["id"] == session["user_id"]:
                row_1["participants_list"] += "Me"
            else:
                row_1["participants_list"] += row_2["name"]
            row_1["participants_list"] += ", "
        # Truncate last ", " from string
        row_1["participants_list"] = row_1["participants_list"][0:len(row_1["participants_list"]) - 2]

        # Determine whether a conversation has unread messages for client display
        rows_2 = db.execute("SELECT last_read FROM participants WHERE conv_id = :cid AND user_id = :uid",
                            cid=row_1["id"], uid=session["user_id"])
        if rows_2[0]['last_read'] - row_1['last_sent'] <= 0:
            row_1["is_new"] = 1
        else:
            row_1["is_new"] = 0

    # Sort first by whether a conversation has new messages, then by time of last sent message
    rows_1.sort(key=lambda x: (x['is_new'], x['last_sent']), reverse=True)

    # If user was directed here after creating a new conversation, inform the client for further action
    # (must go after the above lamda sort to ensure placement in the 0th index of rows_1)
    if len(rows_1) > 0 and session['user_id'] in show_once:
        rows_1[0]['show_once'] = show_once[session['user_id']]
        del show_once[session['user_id']]

    rows_1[0]['new_friends'] = new_friends

    # Emit response back to requesting client
    print('convs server:', request.sid)
    socketio.emit('convs server', rows_1, callback=cb, room=request.sid)

#########################################


@socketio.on('conv client')
# Called to parse/display/refresh a single conversation in messenger
def conv_client(json, methods=['GET', 'POST']):
    print('conv client:', request.sid)
    if duplicate_session():
        return

    db = SQL("sqlite:///db.db")

    # Security check: make sure user is a member of conversation
    rows = db.execute("SELECT * FROM participants WHERE user_id = :uid AND conv_id = :cid",
                      uid=session["user_id"], cid=json["conv_id"])
    if len(rows) < 1:
        return

    # Get all messages in conversation
    rows_1 = db.execute("SELECT * FROM messages WHERE conv_id = :cid",
                        cid=json["conv_id"])
    if len(rows_1) == 0:
        return

    for row_1 in rows_1:
        # If the message is outside the size range, or is an invalid type of media, prevent auto-download
        if row_1["file_name"] != None:
            if len(row_1["ciphertext"]) > max_thumb_size or row_1["thumbable"] is None:
                row_1["ciphertext"] = ""

        # Get name of sender for client display
        rows_2 = db.execute("SELECT * FROM users WHERE id = :fid",
                            fid=row_1["from_id"])
        # Server messages are from a NULL id, giving rows_2 length 0
        if len(rows_2) != 0:
            row_1["name"] = rows_2[0]["name"]
        else:
            row_1["name"] = "Server"

    # Handle reconnection event from client to force a refresh of the conversation
    if "is_reconnect" in json:
        socketio.emit('conv reconnect server', rows_1, callback=cb, room=request.sid)
        return

    # Emit response back to requesting client
    print("conv server:", request.sid)
    socketio.emit('conv server', rows_1, callback=cb, room=request.sid)

#########################################


@socketio.on('read client')
# Called to update last_read time for a given user in a given conversation
def read_client(json, methods=['GET', 'POST']):
    print('read client:', request.sid)
    if duplicate_session():
        return

    db = SQL("sqlite:///db.db")

    db.execute("UPDATE participants SET last_read = ((julianday('now') - 2440587.5) * 86400.0) WHERE conv_id = :cid AND user_id = :uid",
               cid=json["conv_id"], uid=session["user_id"])

    return

#########################################


@socketio.on('file client')
# Called when client is requesting an attachment that was filtered out of auto-download
def file_client(json, methods=['GET', 'POST']):
    print('file client:', request.sid)
    if duplicate_session():
        return

    db = SQL("sqlite:///db.db")

    # Security check: make sure user is allowed to download message
    rows_1 = db.execute("SELECT * FROM messages JOIN conversations ON messages.conv_id = conversations.id JOIN participants ON messages.conv_id = participants.conv_id WHERE messages.id = :id AND participants.user_id = :uid",
                        id=json["msg_id"], uid=session["user_id"])
    if len(rows_1) < 1:
        return

    # Emit response back to requesting client
    socketio.emit('file server', rows_1, callback=cb, room=request.sid)


#########################################
#########################################

@socketio.on('reqscons client')
# Called to display/update/refresh list of friends and requests on the friends page
def reqscons_client(json, methods=['GET', 'POST']):
    print('reqscons client:', request.sid)
    if duplicate_session():
        return

    db = SQL("sqlite:///db.db")

    # Confirm friendship
    if "aid" in json:
        rows_1 = db.execute("SELECT * FROM friendships WHERE requestee_id = :uid AND requester_id = :aid AND mutual = 0",
                            uid=session["user_id"], aid=json["aid"])
        if len(rows_1) == 1:
            db.execute("UPDATE friendships SET mutual = 1 WHERE requestee_id = :uid AND requester_id = :aid",
                       uid=session["user_id"], aid=json["aid"])
            # Force friend requester to send server a friend list refresh
            if rows_1[0]["requester_id"] in client_map:
                print('reqcon server:', client_map[rows_1[0]["requester_id"]])
                socketio.emit('reqcon server', {}, callback=cb, room=client_map[rows_1[0]["requester_id"]])

    # Request friendship
    if "rid" in json:
        rows_1 = db.execute("SELECT * FROM friendships WHERE ((requester_id = :uid AND requestee_id = :rid) OR (requester_id = :rid AND requestee_id = :uid)) AND mutual = 0",
                            uid=session["user_id"], rid=json["rid"])
        if len(rows_1) == 0:
            db.execute("INSERT INTO friendships (requester_id, requestee_id) VALUES(:uid, :rid)",
                       uid=session["user_id"], rid=json["rid"])
            # Force friend requestee to send server a friend list refresh
            if json["rid"] in client_map:
                print('reqcon server:', client_map[json["rid"]])
                socketio.emit('reqcon server', {}, callback=cb, room=client_map[json["rid"]])

    # Find confirmed friends to display on friends list
    rows_1 = db.execute("SELECT * FROM friendships WHERE (requester_id = :uid OR requestee_id = :uid) AND mutual = 1",
                        uid=session["user_id"])
    for row_1 in rows_1:
        # Collect the name of the other user, can be either requester or requestee
        if row_1["requester_id"] == session["user_id"]:
            rows_2 = db.execute("SELECT * FROM users WHERE id = :rid",
                                rid=row_1["requestee_id"])
        else:
            rows_2 = db.execute("SELECT * FROM users WHERE id = :rid",
                                rid=row_1["requester_id"])
        row_1["con_id"] = rows_2[0]['id']
        row_1["con_name"] = rows_2[0]['name']
        row_1["con_username"] = rows_2[0]['username']

    server_response = rows_1

    # Find pending friend requests to display on friends list
    rows_1 = db.execute("SELECT * FROM friendships WHERE requestee_id = :uid AND mutual = 0",
                        uid=session["user_id"])
    for row_1 in rows_1:
        # Collect the name of the other user, can be either requester or requestee
        rows_2 = db.execute("SELECT * FROM users WHERE id = :rid",
                            rid=row_1["requester_id"])
        row_1["req_id"] = rows_2[0]['id']
        row_1["req_name"] = rows_2[0]['name']
        row_1["req_username"] = rows_2[0]['username']

    # Every row in server_response will have either con_id con_name con_username XOR req_id req_name req_username use this on front end when parsing list
    server_response = rows_1 + server_response

    # Except for the last row, which is the user's own info
    rows_1 = db.execute("SELECT id, name, username FROM users WHERE id = :id",
                        id=session["user_id"])
    server_response = server_response + rows_1

    # Emit response back to requesting client
    print('reqscons server:', request.sid)
    socketio.emit('reqscons server', server_response, callback=cb, room=request.sid)

#########################################
#########################################


@socketio.on('rejreq client')
# Called when friend request is rejected by client
def rejreq_client(json, methods=['GET', 'POST']):
    print('rejreq client:', request.sid)
    if duplicate_session():
        return

    db = SQL("sqlite:///db.db")

    # Reject friendship
    db.execute("DELETE FROM friendships WHERE requestee_id = :uid AND requester_id = :aid AND mutual = 0",
               uid=session["user_id"], aid=json["aid"])

    # Force friend requestee to send server a friend list refresh
    print('reqcon server:', request.sid)
    socketio.emit('reqcon server', {}, callback=cb, room=request.sid)

#########################################
#########################################


@socketio.on('search client')
# Called when a user search is requested by client
def search_client(json, methods=['GET', 'POST']):
    print('search client:', request.sid)
    if duplicate_session():
        return

    # Don't allow searches less than 2 characters long
    if len(json["query"]) < 2:
        print('search server:', request.sid)
        socketio.emit('search server', {}, callback=cb, room=request.sid)
        return

    db = SQL("sqlite:///db.db")

    # Search database by name, username and email simultaneously
    rows_1 = db.execute("SELECT id, name, username FROM users WHERE (email = :exact OR username LIKE :query OR LOWER( users.name ) LIKE :query) AND id != :id",
                        exact=json["query"].lower(), query="%"+json["query"].lower()+"%", id=session["user_id"])

    for row_1 in rows_1:
        # Determine friendship status, default is 0, ie NO relationship
        row_1["relationship"] = 0
        rows_2 = db.execute("SELECT * FROM friendships WHERE requester_id = :rid AND requestee_id = :uid AND mutual = 0",
                            uid=session["user_id"], rid=row_1["id"])
        if len(rows_2) != 0:
            # Client has an open friend request FROM this user
            row_1["relationship"] = 1
        else:
            rows_2 = db.execute("SELECT * FROM friendships WHERE requester_id = :uid AND requestee_id = :rid AND mutual = 0",
                                uid=session["user_id"], rid=row_1["id"])
            if len(rows_2) != 0:
                # Client has an open friend request TO this user
                row_1["relationship"] = 2
            else:
                rows_2 = db.execute("SELECT * FROM friendships WHERE ((requester_id = :uid AND requestee_id = :rid) OR (requester_id = :rid AND requestee_id = :uid)) AND mutual = 1",
                                    uid=session["user_id"], rid=row_1["id"])
                if len(rows_2) != 0:
                    # Client is friends with this user
                    row_1["relationship"] = 3

    # Emit response back to requesting client
    print('search server:', request.sid)
    socketio.emit('search server', rows_1, callback=cb, room=request.sid)

#########################################
#########################################


@socketio.on('newconv client')
# Called when client creates a new conversation
def newconv_client(json, methods=['GET', 'POST']):
    print('newconv client:', request.sid)
    if duplicate_session():
        return

    # Force client to name the conversation
    if 'name' not in json:
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': 'Missing conversation name!'}], callback=cb, room=request.sid)
        return

    db = SQL("sqlite:///db.db")

    # Enforce unique one-time-pad usage
    rows_1 = db.execute("SELECT * FROM conversations WHERE pad_hash = :ph",
                        ph=json["pad_hash"])
    if len(rows_1) != 0:
        socketio.emit('msg server', [{'name': 'Server', 'from_id': None,
                                      'ciphertext': 'Pad already in use!'}], callback=cb, room=request.sid)
        return

    # Create new conversation
    conv_id = db.execute("INSERT INTO conversations (name, total_size, pad_hash) VALUES(:nm, :ts, :ph)",
                         nm=json["name"], ts=json["total_size"], ph=json["pad_hash"])

    # Insert users into conversation
    for uid in json['user_ids']:
        db.execute("INSERT INTO participants (user_id, conv_id) VALUES(:uid, :cid)",
                   uid=uid, cid=conv_id)
    db.execute("INSERT INTO participants (user_id, conv_id) VALUES(:uid, :cid)",
               uid=session["user_id"], cid=conv_id)

    # Create default "conversation created by..." message from server
    rows_1 = db.execute("SELECT * FROM users WHERE id = :id",
                        id=session["user_id"])
    db.execute("INSERT INTO messages (conv_id, from_id, pad_index, ciphertext) VALUES(:cid, NULL, 0, :cpt)",
               cid=conv_id, cpt="New conversation: '"+json["name"]+"' started.")
    db.execute("UPDATE conversations SET last_sent = ((julianday('now') - 2440587.5) * 86400.0) WHERE id = :id",
               id=conv_id)

    # This must go after the message insertion above for correct display order by clients
    for uid in json['user_ids']:
        if uid in client_map:
            socketio.emit('convs refresh server', {}, callback=cb, room=client_map[uid])

    # Set the show_once flag so the client can immediately display the conversation in messanger after creating it
    show_once[session['user_id']] = conv_id

    # Emit response back to requesting client
    print('newconv server:', request.sid)
    socketio.emit('newconv server', {}, callback=cb, room=request.sid)


#########################################
#########################################

if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=8080, debug=True)
    # socketio.run(app, host="0.0.0.0", port=8080, debug=True, certfile="mycert.pem", keyfile="mycert.pem")
    # (generate certs): openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout mycert.pem -out mycert.pem